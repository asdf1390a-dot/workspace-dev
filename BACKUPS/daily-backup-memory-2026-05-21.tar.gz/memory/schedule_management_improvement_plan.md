---
name: 스케줄 관리 역량 개선 계획
description: 외부 사례 학습 기반 실행 자동화 전략 (비서 자체 진단 + 팀 적용)
type: feedback
---

## 현황 분석

**외부 학습 결과:** 1000+ 줄의 체계적인 스케줄 관리 프레임워크 이미 자체 구축됨
- TASK_ROADMAP_2026_05.md (161줄) — 임계경로 + 병렬 트랙
- TEAM_ALLOCATION_PLAN_2026_05.md (389줄) — 역할별 할당 + 주간 목표
- TRACKING_PROCESS_IMPROVEMENT_DESIGN.md (429줄) — 5대 문제점 분석 + 해결책
- active_work_tracking.md (CTB) — 실시간 중앙 추적판
- AUDIT_FRAMEWORK_TEAM_DISCUSSION_AGENDA.md — 팀 리뷰 프로세스

**핵심 문제:** 이론은 완벽한데 **실행 시 제때 자동화하지 못함**

## 5대 진단 항목

### 1️⃣ CTB (Central Task Board) 자동 갱신 미작동
- ✅ 정의: 매일 09:00, 18:00 KST 자동 갱신
- ❌ 실제: 수동으로만 갱신됨
- **개선:** Cron job 연계 (기존 HEARTBEAT.md 활용)

### 2️⃣ 팀원 진행 상황 정기 체크 없음
- ✅ 정의: Web-Builder AI Agent, Evaluator AI Agent, Planner AI Agent 각자 배치됨
- ❌ 실제: 위임 후 진행 상황을 자동으로 수집하지 않음
- 예시: Asset Master Phase 1이 지금 몇 % 진행 중인지 모름
- **개선:** 매일 15:00 KST (Web-Builder AI Agent), 12:00 KST (Evaluator AI Agent), 14:00 KST (Planner AI Agent) 정기 보고

### 3️⃣ 의존성 자동 준비 부족
- ❌ Travel Phase 2가 Asset Master 완료에 의존하나, 준비 단계 자동 트리거 없음
- ❌ Asset Master 50% 도달 시점에 Travel 사전 리뷰를 자동으로 시작하지 않음
- **개선:** 의존성 기반 자동 준비 체크리스트 (진도 50% → 다음 단계 사전 준비 시작)

### 4️⃣ 리스크 감지 없음
- ❌ Asset Master가 마감 2026-05-28인데, 진도 < 계획 진도여도 자동 알람 없음
- ❌ 일정 슬립 가능성을 미리 감지하지 못함
- **개선:** 주 2회 리스크 스캔 (진도 편차, 팀원 과부하, 블로킹 아이템)

### 5️⃣ 블로킹 아이템 추적 약함
- ❌ 매번 "뭐가 막혔나?"를 수동으로 확인해야 함
- ❌ "사용자 액션 필요" 항목 자동 리마인드 없음
- **개선:** 매일 자동 스캔 + 1일 1회 리마인드

## 개선 전략

### Phase A: 즉시 (오늘부터)

**A1. 팀원 정기 체크 자동화**
```
Asset Master Phase 1 (web-builder):
  - 매일 15:00 KST: "지금 몇 % 진행? 블로킹은?" 정기 문의
  - CTB 즉시 갱신 (진도 %, 예상 완료 시간 조정)

Backup Phase 2 UI (evaluator):
  - 매일 12:00 KST: "검증 진행률? 몇 회 반복 완료?" 정기 문의
  - CTB 갱신 (검증 횟수, 발견 이슈)

Audit System (planner):
  - 매일 14:00 KST: "팀 논의 참여? 의견 수렴?" 정기 문의
  - CTB 갱신 (논의 진도 %, 미결정 항목)
```

**A2. 의존성 준비 시작**
- Asset Master 진도 50% 도달 → Travel Phase 2 "준비 단계" 자동 시작
- Web-Builder AI Agent에게 사전 안내: "다음 작업 Asset Master 완료 후 바로 Travel로 전환"

**A3. 리스크 감지 규칙**
- 매주 월/목 15:00 KST: Asset Master 진도 < 계획 진도 → 자동 알람
- 팀원 3개 이상 동시 진행 감지 → "우선순위 재평가 필요" 알람

### Phase B: 1주일 (2026-05-22까지)

**B1. CTB 자동 갱신 완전 자동화**
- HEARTBEAT.md 에 매일 09:00, 18:00 KST CTB 갱신 작업 추가
- 팀원 진행 현황을 자동으로 수집 (정해진 시간에 Telegram으로 리포트 요청)

**B2. 팀원 과부하 감시**
- 동시 진행 작업 > 2개 → 우선순위 재평가 필요 신호
- 예: Web-Builder AI Agent가 Asset Master + Travel Phase 2 사전 준비 3개 동시 진행 시 "부하 체크" 알람

**B3. 블로킹 아이템 자동 추적**
- 매일 08:30 KST: CTB에서 🔴 항목 스캔
- "사용자 액션 필요" 항목이 있으면 18:00 KST에 리마인드

### Phase C: 2주일 (2026-05-29까지)

**C1. 예측 기반 스케줄링**
- 각 팀원의 과거 진도 데이터 수집 (2주)
- "Asset Master → 예상 완료일이 정말 2026-05-28인가?" 재계산
- Travel Phase 2 시작 시점 조정 (슬립 예상 시 사전 알람)

**C2. 의존성 그래프 자동 갱신**
- CTB에 의존성 다이어그램 자동 표시
- "Asset Master 50% → Travel 준비 시작" 자동 트리거

## 적용 규칙 (앞으로 절대)

**Rule 1: 정해진 시간에 팀원 현황 수집**
- 안 함 → 지금부터는 무조건 함
- Tool: Telegram 메시지로 정기 문의 + CTB 자동 갱신

**Rule 2: 일정 슬립 감지 → 즉시 다음 단계 준비**
- 안 함 → 지금부터는 무조건 함
- 도구: 주간 리스크 스캔 (월/목 15:00 KST)

**Rule 3: 의존성 준비는 자동**
- 안 함 → 지금부터는 무조건 함
- 예: Asset Master 50% → Travel 사전 준비 자동 시작 신호

**Rule 4: 블로킹 아이템 매일 스캔**
- 안 함 → 지금부터는 무조건 함
- "사용자 액션 필요"는 1일 1회 리마인드

## 예상 효과

| 항목 | 현재 | 개선 후 |
|------|-----|--------|
| CTB 갱신 | 수동 (간헐) | 자동 (매일 2회) |
| 팀원 진도 추적 | 모름 | 매일 정기 보고 |
| 일정 슬립 감지 | 미리 모름 | 주 2회 자동 감지 |
| 의존성 준비 | 수동 | 자동 트리거 |
| 블로킹 아이템 | 때때로 | 매일 자동 스캔 |

## 팀원 동의 필요

- Web-Builder AI Agent: 매일 15:00 KST 진도 리포트 (5분, Telegram)
- Evaluator AI Agent: 매일 12:00 KST 검증 진도 리포트 (5분, Telegram)
- Planner AI Agent: 매일 14:00 KST 팀 논의 진행 리포트 (5분, Telegram)

---

**적용 시작:** 2026-05-15 17:00 KST (지금부터)
**첫 정기 체크:** 2026-05-15 17:00 (Web-Builder AI Agent Asset Master 진도)
