---
name: Data-Analyst AI Agent 프로젝트 완료 보고서
description: 각 프로젝트 완료시 Data-Analyst AI Agent가 완료 보고서 작성 (필수 규칙)
type: feedback
---

# Data-Analyst AI Agent 프로젝트 완료 보고서 규칙

**규칙:** 프로젝트/기능 개발 완료할 때마다 Data-Analyst AI Agent가 **완료 보고서**를 작성

**보고서 범위:**
- 개발 요구사항 검토
- 구현된 기능 검증
- 데이터 정합성/성능 확인
- 위험 요소 및 개선안 제시
- 최종 승인/조건부 승인 판정

**형식:**
1. 프로젝트명 + 완료일
2. 검증 항목별 평가 (체크리스트)
3. 발견 이슈 (있으면)
4. 최종 판정 (✅ 승인 / 🟡 조건부 / 🔴 재검토 필요)

**Why:** 각 프로젝트 완료시 데이터 관점의 최종 품질 보증이 필요. 구현 후 배포 전 마지막 검증 레이어.

**How to apply:**
- Backup Phase 2 API 완료 → 완료 보고서 작성
- Asset Master Phase 2 API 완료 → 완료 보고서 작성
- Travel Phase 2 완료 → 완료 보고서 작성
- Audit System 구현 완료 → 완료 보고서 작성
- (모든 주요 프로젝트 완료시 적용)

**필요 스킬:**
- API 응답값 검증 (data type, null 처리, boundary cases)
- Supabase 쿼리 성능 검토 (인덱스, 응답시간)
- 데이터 무결성 검증 (FK 관계, 중복 데이터, 타입 일치)
- 비즈니스 로직 검증 (계산 오류, 경계값 처리)
- 리포트 작성 (Markdown, 테이블, 스크린샷)

**시작:** 2026-05-15 (이 규칙 확정부터)
