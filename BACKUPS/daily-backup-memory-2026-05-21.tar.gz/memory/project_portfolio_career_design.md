---
name: 경력 포트폴리오 설계
description: 6년 경력 데이터 + 시각화로 포트폴리오화 (/career 라우트, 5개 페이지, 개발 3주)
type: project
relatedFiles: PORTFOLIO_CAREER_DESIGN.md
date: 2026-05-15
---

# JEEPNEY 경력 포트폴리오 설계

**작성일:** 2026-05-15  
**완료 예상:** 3주 (개발 + 테스트)  
**라우트:** `/career`

## 목적

사용자의 인도 첸나이 법인 2019~2024년 6년 경력을 정량화된 데이터와 시각화로 포트폴리오화하여 경영진/기술팀에 가시화

## 핵심 기능

1. **경력 요약 (Hero)** — 6년 경력, 5개 핵심 성과 카드
2. **성과 대시보드** — 연도별 KPI 트렌드 (4개 차트: 절감액, 효율, LOSS, 노무비율)
3. **성과 상세** — 5개 섹션 (원가절감, 생산성, 설비, 공정, 조직)
4. **경력 타임라인** — 2019~2024 연도별 사진/설명
5. **프로젝트 분류** — 회사별/카테고리별 필터링

## 화면 구조 (5개 메인 페이지)

### 1. Career 메인 페이지 (`/career`)

**Hero Section:**
```
6년    5개    325억원   96%
경력   성과   총절감    최고효율
```

**핵심 성과 5개 카드:**
- 💰 원가절감 (325억원)
- 📈 생산성 (66→96%)
- 🔧 설비 (50억절감)
- ⚙️ 공정 (가스절감)
- 👥 조직 (2.2배성장)

**컴포넌트:**
- `CareerHeroSection` — 배경, 타이틀, 4개 메트릭
- `AchievementCardsGrid` — 5개 성과 카드
- `NavigationTabs` — 4개 탭 (대시보드, 성과상세, 타임라인, 프로젝트)

### 2. 성과 대시보드 (`/career/dashboard`)

**4개 차트:**
1. 절감액 트렌드 (2019~2024 연도별)
2. 효율율 트렌드 (66% → 96%)
3. LOSS율 트렌드
4. 노무비율 트렌드

### 3. 성과 상세 (`/career/achievements`)

**5개 섹션:**
1. 원가절감 (구성: 인력, 자재, 에너지)
2. 생산성 (효율율, 가동률, 납기율)
3. 설비개선 (가동률, MTBF, 투자액)
4. 공정개선 (불량률, 사이클타임, 에너지)
5. 조직역량 (팀 구성, 교육, 승진)

### 4. 타임라인 (`/career/timeline`)

**연도별 마일스톤:**
- 2019: 첫 부임, 기초 다지기
- 2020: 원가절감 1차 (50억)
- 2021: 생산성 개선 (66% → 80%)
- 2022: 설비 현대화 (100억 투자)
- 2023: 조직 확대 (팀 2배)
- 2024: 최고 성과 (96% 효율)

### 5. 프로젝트 필터 (`/career/projects`)

**필터링:**
- 회사별 (Abb Motors, Amphenol, DSC, Others)
- 카테고리별 (원가, 생산, 설비, 공정, 조직)
- 연도별 (2019~2024)

## 기술 구성

**Frontend:**
- Next.js 14 (라우팅, SSR)
- React (컴포넌트)
- Recharts (4개 차트)
- Tailwind CSS (스타일)

**Backend:**
- `pages/api/career/summary.ts` — 경력 요약 데이터
- `pages/api/career/dashboard.ts` — 4개 차트 데이터
- `pages/api/career/achievements.ts` — 성과 상세 데이터
- `pages/api/career/timeline.ts` — 타임라인 데이터
- `pages/api/career/projects.ts` — 프로젝트 목록

**Database:**
- `career_achievements` 테이블 (성과 마스터)
- `career_projects` 테이블 (프로젝트 리스트)
- `career_metrics` 테이블 (월별 지표)

## 개발 로드맵

| 주 | 담당 | 내용 | 완료 |
|----|------|------|------|
| Week 1 | Web-Builder AI Agent | 페이지 레이아웃 + 컴포넌트 | 2026-05-22 |
| Week 2 | Web-Builder AI Agent | API 구현 + DB 쿼리 | 2026-05-29 |
| Week 3 | Evaluator AI Agent | 테스트 + 배포 | 2026-06-05 |

## 성과 지표

- 페이지 로드시간: <2s
- 반응성: 모바일/데스크톱 100%
- 데이터 정확도: 100% (회계 검증)

## 참고 문서
- PORTFOLIO_CAREER_DESIGN.md — 전체 상세 설계
